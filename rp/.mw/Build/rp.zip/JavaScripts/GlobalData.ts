﻿
export default class GlobalData {
    public static languageId: number = 1;

    public static bagCount: number = 5;
}