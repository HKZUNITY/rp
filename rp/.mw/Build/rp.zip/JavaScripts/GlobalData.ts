﻿
export default class GlobalData {
    public static languageId: number = 1;

    /**是否开启IAA */
    public static isOpenIAA: boolean = false;

    public static bagCount: number = 5;

    public static worldCount: number = 500;

    public static freeTime: number = 8;
}